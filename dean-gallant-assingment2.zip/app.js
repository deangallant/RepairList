const requiredRepair = document.querySelector('.new-repair');
const listOfRepairs = document.querySelector('.repair-list');
const clearCompleted = document.querySelector('.clear-completed')

requiredRepair.addEventListener('keydown', function (e) {
  
  if (e.code === 'Enter' || e.code === 'NumpadEnter') {
    if (e.target.value !== '') {
    myrepairList.addRepair(e.target.value)
}
    const view = document.querySelector('.view');

    view.addEventListener('click', function (event) {
      if (event.target.nodeName === 'INPUT') {
        myrepairList.markAsComplete(event)
      }
    })

    e.target.value = ''
    e.preventDefault()
  } 
}
)

class RepairList {
  constructor(){
    this.repairsArr = []
  }

addRepair(description) {
  this.repairsArr.push(description)
  listOfRepairs.insertAdjacentHTML('afterbegin',`
  <li data-id="${this.repairsArr.length -1}" class="">
  <div class="view">
    <input class="toggle" type="checkbox">
    <label>${description}</label>
    <button class="destroy"></button>
  </div>
</li>
`
)  
}

deleteRepair(id) {
}

markAsComplete(event) {
  event.target.parentElement.parentElement.classList.toggle('completed')
}

clearCompleted() {
  listOfRepairs.innerHTML = '';
  this.repairsArr = [];
}
}

let myrepairList = new RepairList;

class Repair {
  constructor(description){
  this.description = description;
  this.completed = false;
  this.id = repairsArr.length;
  }
}

clearCompleted.addEventListener('click', function () {
  myrepairList.clearCompleted()
})